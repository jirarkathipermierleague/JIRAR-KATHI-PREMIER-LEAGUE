JPL — JIRAR KATHI PREMIER LEAGUE 2026

This is the B / Professional version requested by the user.
It includes a mobile-friendly website and a built-in Admin Panel.

ADMIN:
Default password: jpl2026
Change the password inside app.js before publishing.

The Admin Panel lets you:
- Add/delete team names
- Add/delete fixtures
- Enter match results
- Edit tournament rules
- Automatically calculate standings, W/D/L, GF, GA, GD and points

IMPORTANT:
This version stores edits in the browser's localStorage. That means edits made on one phone/browser are not automatically shared to other people's devices. For a truly shared online admin system, the site needs a cloud database/backend (for example Firebase/Supabase).

PUBLISH:
Upload all files to a static hosting service such as GitHub Pages, Netlify, or Cloudflare Pages.
